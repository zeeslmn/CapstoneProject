<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\orangtua;

class OrangTuaController extends Controller
{
    public function index()
    {
        $data = orangtua::all();
        return view('orangtua/orangtua', compact('data'));
    }

    public function create()
    {
        return view('orangtua/orangtua_buat');
    }

    public function post(Request $request)
    {
        orangtua::create([
            'nama' => $request->nama,
            'nik' => $request->nik,
            'email' => $request->email,
            'kelamin' => $request->kelamin,
            'tempatlahir' => $request->tempatlahir,
            'tanggallahir' => $request->tanggallahir,
            'alamat' => $request->alamat,
            'telp' => $request->telp,
        ]);

        return redirect('/orangtua');
    }

    public function edit($id)
    {
        $data = orangtua::where('id','=',$id)->first();
        return view('orangtua/orangtua_edit', compact('data'));
    }

    public function update(Request $request, $id)
    {
        $data = orangtua::where('id', $id)->update([
            'nama' => $request->nama,
            'nik' => $request->nik,
            'email' => $request->email,
            'kelamin' => $request->kelamin,
            'tempatlahir' => $request->tempatlahir,
            'tanggallahir' => $request->tanggallahir,
            'alamat' => $request->alamat,
            'telp' => $request->telp,
        ]);

        return redirect('/orangtua');
    }

    public function delete($id)
    {
        $data = orangtua::where('id', $id)->first();
        $data->delete();

        return redirect('/orangtua');
    }
}
