<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\balita;

class BalitaController extends Controller
{
    public function index()
    {
        $data = balita::all();
        return view('balita/balita', compact('data'));
    }

    public function create()
    {
        return view('balita/balita_buat');
    }

    public function post(Request $request)
    {
        balita::create([
            'namabalita' => $request->namabalita,
            'namaorangtua' => $request->namaorangtua,
            'nikbalita' => $request->nikbalita,
            'nikorangtua' => $request->nikorangtua,
            'kelamin' => $request->kelamin,
            'tempatlahir' => $request->tempatlahir,
            'tanggallahir' => $request->tanggallahir,
            'beratbadan' => $request->beratbadan,
            'tinggibadan' => $request->tinggibadan,
            'lingkarbadan' => $request->lingkarbadan,
            'goldar' => $request->goldar,
        ]);

        return redirect('/balita');
    }
    
    public function edit($id)
    {
        $data = balita::where('id','=',$id)->first();
        return view('balita/balita_edit', compact('data'));
    }

    public function update(Request $request, $id)
    {
        $data = balita::where('id', $id)->update([
            'namabalita' => $request->namabalita,
            'namaorangtua' => $request->namaorangtua,
            'nikbalita' => $request->nikbalita,
            'nikorangtua' => $request->nikorangtua,
            'kelamin' => $request->kelamin,
            'tempatlahir' => $request->tempatlahir,
            'tanggallahir' => $request->tanggallahir,
            'beratbadan' => $request->beratbadan,
            'tinggibadan' => $request->tinggibadan,
            'lingkarbadan' => $request->lingkarbadan,
            'goldar' => $request->goldar,
        ]);

        return redirect('/balita');
    }

    public function delete($id)
    {
        $data = balita::where('id', $id)->first();
        $data->delete();

        return redirect('/balita');
    }

}