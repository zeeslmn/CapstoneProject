<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\laporan;

class LaporanController extends Controller
{
    public function index()
    {
        $data = laporan::all();
        return view('laporan/laporan', compact('data'));
    }

    public function create()
    {
        return view('laporan/laporan_buat');
    }

    public function post(Request $request)
    {
        Laporan::create([
            'namabalita' => $request->namabalita,
            'namaorangtua' => $request->namaorangtua,
            'kelamin' => $request->kelamin,
            'imunisasi' => $request->imunisasi,
            'vitamin' => $request->vitamin,
            'goldar' => $request->goldar,
        ]);

        return redirect('/laporan');
    }
    
    public function edit($id)
    {
        $data = Laporan::where('id','=',$id)->first();
        return view('laporan/laporan_edit', compact('data'));
    }

    public function update(Request $request, $id)
    {
        $data = Laporan::where('id', $id)->update([
            'namabalita' => $request->namabalita,
            'namaorangtua' => $request->namaorangtua,
            'kelamin' => $request->kelamin,
            'imunisasi' => $request->imunisasi,
            'vitamin' => $request->vitamin,
            'goldar' => $request->goldar,
        ]);

        return redirect('/laporan');
    }

    public function delete($id)
    {
        $data = Laporan::where('id', $id)->first();
        $data->delete();

        return redirect('/laporan');
    }
}
