<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class balita extends Model
{
    use HasFactory;
    protected $table='balita';
    protected $fillable = [
        'namabalita',
        'namaorangtua',
        'nikorangtua',
        'nikbalita',
        'kelamin',
        'tempatlahir',
        'tanggallahir',
        'beratbadan',
        'tinggibadan',
        'lingkarbadan',
        'goldar',
    ];
}
