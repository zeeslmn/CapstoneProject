
<?php $__env->startSection('konten'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Formulir Tambah Data Balita</h3>
                </div>
                <div class="card-body">
                <form method="post" action="/balita/post">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Nama Balita</label>
                                    <input type="text" class="form-control" name="namabalita">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Nama Orang Tua</label>
                                    <input type="text" class="form-control" name="namaorangtua">
                                </div>
                            </div>      
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>NIK balita</label>
                                    <input type="text" class="form-control" name="nikbalita">
                                </div>
                            </div>    
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>NIK Orang Tua</label>
                                    <input type="text" class="form-control" name="nikorangtua">
                                </div>
                            </div> 
                        </div>
                    </div > 
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Jenis Kelamin</label>
                            <select name="kelamin" class="form-control">
                                <option value="">---Silahkan pilih jenis kelamin---</option>
                                <option value="Laki-laki">Laki - laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Tempat Lahir</label>
                            <input type="text" class="form-control" name="tempatlahir">
                        </div>
                        <div class="form-group">
                            <label for="">Tanggal Lahir</label>
                            <input type="date" class="form-control" name="tanggallahir">
                        </div>
                        <div class="form-group">
                            <label for="">Berat Badan</label>
                            <input type="number" class="form-control" name="beratbadan">
                        </div>
                        <div class="form-group">
                            <label for="">Tinggi Badan</label>
                            <input type="number" class="form-control" name="tinggibadan">
                        </div>
                        <div class="form-group">
                            <label for="">Lingkar Badan</label>
                            <input type="number" class="form-control" name="lingkarbadan">
                        </div>
                        <div class="form-group">
                            <label for="">Golongan Darah</label>
                            <select name="goldar" class="form-control">
                                <option value="">---Silahkan pilih golongan darah---</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="AB">AB</option>
                                <option value="O">O</option>
                            </select>
                        </div>
                    </div>
                    <center>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    </center>
                    </form>
                    </div>  
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\eposyandu\resources\views/balita/balita_buat.blade.php ENDPATH**/ ?>