
<?php $__env->startSection('konten'); ?>
<div class="container-fluid">
    <h1>Welcome !</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\eposyandu\resources\views/admin.blade.php ENDPATH**/ ?>