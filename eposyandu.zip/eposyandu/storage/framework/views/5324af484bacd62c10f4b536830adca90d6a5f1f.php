
<?php $__env->startSection('konten'); ?>
<div class="row">
    <div class="container-fluid">

        <h1>INI HALAMAN ORANG TUA</h1>
        </div>
    </div>
<div class="row">
    <div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Data Orang Tua</h3>
        </div>
        <div class="card-body">
        <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="row mb-2">
                                    <a href="/orangtua/create" class="btn btn-primary btn-sm">Tambah <span class="fa fa-plus"></span></a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>NIK</th>
                                            <th>Nama</th>
                                            <th>Jenis Kelamin</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($dt->nik); ?></td>
                                            <td><?php echo e($dt->nama); ?></td>
                                            <td><?php echo e($dt->kelamin); ?></td>
                                            <td>
                                                <a href="/orangtua/<?php echo e($dt->id); ?>/edit" class="btn btn-warning">Edit</a>
                                                <a href="/orangtua/<?php echo e($dt->id); ?>/delete" class="btn btn-danger">Hapus</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\eposyandu\resources\views/orangtua/orangtua.blade.php ENDPATH**/ ?>