
<?php $__env->startSection('konten'); ?>
<div class="row">
        <div class="col">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Data Laporan</h3>
                    </div>
                    <div class="card-body">
                        <div class="card shadow mb-12">
                            <div class="card-body">
                                <div class="col-md-12">
                                <div class="table table-responsive">
                                <table class="table table-stripped" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Balita</th>
                                            <th>Nama Orang Tua</th>
                                            <th>Jenis Kelamin</th>
                                            <th>Jenis Imunisasi</th>
                                            <th>Jenis Vitamin</th>
                                            <th>Golongan Darah</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($dt->namabalita); ?></td>
                                            <td><?php echo e($dt->namaorangtua); ?></td>
                                            <td><?php echo e($dt->kelamin); ?></td>
                                            <td><?php echo e($dt->imunisasi); ?></td>
                                            <td><?php echo e($dt->vitamin); ?></td>
                                            <td><?php echo e($dt->goldar); ?></td>
                                            <td>
                                                <a href="/laporan/<?php echo e($dt->id); ?>/edit" class="btn btn-warning">Edit</a>
                                                <a href="/laporan/<?php echo e($dt->id); ?>/delete" class="btn btn-danger">Hapus</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                    <div class="row col-4">
                                        <a href="/laporan/create" class="btn btn-primary btn-sm">Tambah <span class="fa fa-plus"></span></a>
                                    </div>
                                    <br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\eposyandu\resources\views/laporan/laporan.blade.php ENDPATH**/ ?>