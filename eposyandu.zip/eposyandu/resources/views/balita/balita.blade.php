@extends('master')
@section('konten')
    <div class="row">
        <div class="col">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Data Balita</h3>
                    </div>
                    <div class="card-body">
                        <div class="card shadow mb-12">
                            <div class="card-body">
                                <div class="col-md-12">
                                <div class="table table-responsive">
                                <table class="table table-stripped" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Balita</th>
                                            <th>Nama Orang Tua</th>
                                            <th>Jenis Kelamin</th>
                                            <th>Berat Badan</th>
                                            <th>Tinggi Badan</th>
                                            <th>Lingkar Badan</th>
                                            <th>Golongan Darah</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                        $no = 1;
                                        @endphp
                                        @foreach($data as $dt)
                                        <tr>
                                            <td>{{$no++}}</td>
                                            <td>{{$dt->namabalita}}</td>
                                            <td>{{$dt->namaorangtua}}</td>
                                            <td>{{$dt->kelamin}}</td>
                                            <td>{{$dt->beratbadan}}</td>
                                            <td>{{$dt->tinggibadan}}</td>
                                            <td>{{$dt->lingkarbadan}}</td>
                                            <td>{{$dt->goldar}}</td>
                                            <td>
                                                <a href="/balita/{{$dt->id}}/edit" class="btn btn-warning">Edit</a>
                                                <a href="/balita/{{$dt->id}}/delete" class="btn btn-danger">Hapus</a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                    <div class="row col-4">
                                        <a href="/balita/create" class="btn btn-primary btn-sm">Tambah <span class="fa fa-plus"></span></a>
                                    </div>
                                    <br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection