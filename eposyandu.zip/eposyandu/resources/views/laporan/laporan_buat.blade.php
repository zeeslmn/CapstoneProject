@extends('master')
@section('konten')

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Formulir Tambah Data Laporan</h3>
                </div>
                <div class="card-body">
                <form method="post" action="/laporan/post">
                    @csrf
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Nama Balita</label>
                                    <input type="text" class="form-control" name="namabalita">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Nama Orang Tua</label>
                                    <input type="text" class="form-control" name="namaorangtua">
                                </div>
                            </div>       
                        </div>
                    </div > 
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Jenis Kelamin</label>
                            <select name="kelamin" class="form-control">
                                <option value="">---Silahkan pilih jenis kelamin---</option>
                                <option value="Laki-laki">Laki - laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Jenis Imunisasi</label>
                                        <input type="text" class="form-control" name="imunisasi">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Jenis Vitamin</label>
                                        <input type="text" class="form-control" name="vitamin">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Golongan Darah</label>
                            <select name="goldar" class="form-control">
                                <option value="">---Silahkan pilih golongan darah---</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="AB">AB</option>
                                <option value="O">O</option>
                            </select>
                        </div>
                    </div>
                    <center>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    </center>
                    </form>
                    </div>  
                </div>
        </div>
    </div>
</div>
@endsection