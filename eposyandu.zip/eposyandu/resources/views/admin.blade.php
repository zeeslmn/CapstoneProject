@extends('master')
@section('konten')
<div class="container-fluid">
    <h1>Welcome !</h1>
</div>
@endsection