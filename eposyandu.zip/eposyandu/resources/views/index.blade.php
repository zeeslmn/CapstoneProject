
<!DOCTYPE html>
<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <title>ePosyandu - Manajemen Pasien Posyandu</title>
    <link rel="icon" href="http://efarmasi.id/style/images/favicon.ico"" type="image/png" sizes="16x16">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Label Multipurpose Startup Business Template">
    <meta name="keywords" content="Label HTML Template, Label Startup Business Template, Startup Template">
    <link href="https://eposyandu.id/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600%7COpen+Sans:400%7CVarela+Round" rel="stylesheet">
 <!-- Resource style -->
    <link rel="stylesheet" href="https://eposyandu.id/assets/css/owl.carousel.css">
    <link rel="stylesheet" href="https://eposyandu.id/assets/css/owl.theme.css">
    <link rel="stylesheet" href="https://eposyandu.id/assets/css/jquery.accordion.css">
    <link rel="stylesheet" href="https://eposyandu.id/assets/css/magnific-popup.css">
    <link rel="stylesheet" href="https://eposyandu.id/assets/css/ionicons.min.css"> <!-- Resource style -->
    <link href="https://eposyandu.id/assets/css/style.css" rel="stylesheet" type="text/css" media="all" />
  </head>
  <body>
    <div class="wrapper">
      <div class="container">
        <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top" style="background-color:#000">
          <div class="container-fluid">
            <a class="navbar-brand" href="#">
              <img src="https://bondowosokab.go.id/frontend/images/logo/LogoPemkab2021.png" data-at2x="https://bondowosokab.go.id/frontend/images/logo/LogoPemkab2021.png" class="alt-logo" alt="" width="100pt" height="30pt">
            </a>
            <a class="navbar-brand" href="#">
            <span class="highlight2">ePosyandu Penambangan</span>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav ml-auto navbar-right">
                  <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#main">Home</a></li>
                  <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#about">About</a></li>
                  <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#services">Features</a></li>
                  <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#pricing">Client</a></li>
                  <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#footer">Contact</a></li>
                  <li class="nav-item"><a class="nav-link" href="login">Login Admin</a></li>
              </ul>
            </div>
          </div>
        </nav>
      </div>

      <div id="main" class="main">
        <div class="features home-2">
          <style>
            bg {
              background-image: url()
            }
          </style>
          <div class="container">
            <div class="row align-center">
              <div class="col-md-12 col-lg-5">
                <div class="hero-content">
                  <h4>Penambangan Integrated eHealth Platform</h4>
                  <h1><span class="highlight2">ePosyandu</span></h1>
                  <p style="font-size: 14px!important">Digitalisasi pelayanan Posyandu secara 
                    <span style="font-style:italic;"> Paperless, Online</span> & Terintegrasi dengan Posyandu Desa Penambangan, Kecamatan Curahdami, Kabupaten Bondowoso.</p>
                </div>
              </div>
              <div class="col-md-12 col-lg-6 offset-lg-1">
                <img class="img-fluid" src="https://eposyandu.id/assets/images/mb.png" alt="Home">
              </div>
            </div>
          </div>
        </div>

        <div id="about" class="about">
          <div class="flex-split">
              <div class="container">
                <div class="row align-center">
                  <div class="col-md-5">
                    <div class="f-left">
                      <div class="left-content wow fadeInLeft" data-wow-delay="0s">
                        <h2>About <span class="highlight">ePosyandu</span></h2>
                        <p style="text-align:justify">PT Infokes Indonesia mulai melakukan implementasi produk ePuskesmas semenjak tahun 2013, sampai saat ini lebih dari 1000 puskesmas dan 50 Dinkes Kota / Kabupaten di Indonesia telah menggunakan produk tersebut. Untuk meningkatkan kualitas, performa produk dan layanan team Infokes terus melakukan inovasi dan transformasi dengan menghadirkan ePosyandu . Semoga dengan kehadiran ePosyandu beserta fitur-fitur unggulanya akan lebih memantapkan posisi Infokes Indonesia sebagai penyedia layanan kesehatan online dan terintegrasi terbaik di Indonesia.
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6 offset-md-1">
                    <div class="f-right">
                      &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                      <img class="img-fluid" src="https://promkes.kemkes.go.id/imagex/footer/logo_kemenkes.png" alt="Feature" width="50%">
                    </div>
                  </div>
                </div>
              </div>
            </div>


           <div id="services" class="lbl-services" style="background:#f0f0f0!important">
          <div class="container">
            <div class="row justify-center">
              <div class="col-md-8">
                <div class="service-intro text-center">
                 <h1 class="wow fadeInDown">Featured <span class="highlight">ePosyandu</span></h1>
                 <h6>
                   Fitur-fitur yang memudahkan dalam mendata pasien Posyandu 
                </h6>
                </div>
              </div>
           
               <div class="row">
              <div class="col-sm-4 wow fadeInDown" data-wow-delay="0.1s">
                <div class="lbl-service-card">
                  <div class="card-icon">
                    <img src="https://eposyandu.id/assets/icons/pricing-1.png" width="60" alt="Feature">
                  </div>
                  <div class="card-text">
                    <h1>Cloud Computing</h1>
                    <p>Aplikasi sangat mudah di akses dimana saja, kapan saja dan melalui perangkat apa saja.</p>
                  </div>
                </div>
              </div>
              <div class="col-sm-4 wow fadeInDown" data-wow-delay="0.1s">
                <div class="lbl-service-card">
                  <div class="card-icon">
                    <img src="https://eposyandu.id/assets/icons/downloads.png" width="60" alt="Feature">
                  </div>
                  <div class="card-text">
                    <h1>Terintegrasi Dashboard Balai Desa</h1>
                    <p>Terintegrasi dengan Dashboard Kelurahan, Kecamatan , & Kota /Kab.</p>
                  </div>
                </div>
              </div>
              <div class="col-sm-4 wow fadeInDown" data-wow-delay="0.1s">
                <div class="lbl-service-card">
                  <div class="card-icon">
                    <img src="https://eposyandu.id/assets/icons/projects.png" width="60" alt="Feature">
                  </div>
                  <div class="card-text">
                    <h1>Create Automaticly Report</h1>
                    <p>Merekap secara otomatis semua laporan yang dibutuhkan</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

</div>
       
           <div id="features" class="#" style="background:#f0f0f0!important">
          <div class="flex-split">
            <div class="container">
              <div class="row align-center">
                <div class="col-md-5">
                  <div class="f-left">
                    <div class="left-content wow fadeInLeft" data-wow-delay="0s">
                      <h2>eKMS</h2>
                      <p > KMS digital yang dapat mempermudah petugas Posyandu dalam membaca tumbuh kembang bayi/balita dengan sangat mudah dan praktis.
                    </div>
                  </div>
                </div>
                <div class="col-md-6 offset-md-1">
                  <div class="f-right">
                    <img class="img-fluid" src="https://eposyandu.id/assets/images/f1.png" alt="Feature">
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="flex-split" style="background:#fff !important">
            <div class="container">
              <div class="row align-center">
                <div class="col-md-6">
                  <div class="f-right">
                    <img class="img-fluid" src="https://eposyandu.id/assets/images/terintegrasi.svg" alt="Feature">
                  </div>
                </div>
                <div class="col-md-5  offset-md-1">
                  <div class="f-left">
                    <div class="left-content wow fadeInLeft" data-wow-delay="0s">
                       <h2>Terintegrasi Dashboard Kelurahan</h2>
                    <p>Terintegrasi dengan Dashboard Kelurahan, Kecamatan , & Kota /Kab.</p>                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>


            <div class="flex-split" style="background: #3f9cfbb3;">
            <div class="container">
              <div class="row align-center">
                <div class="col-md-5">
                  <div class="f-left">
                    <div class="left-content wow fadeInLeft" data-wow-delay="0s">
                      <h2 style="color: white;">Cloud Computing</h2>
                      <p style="color: white;"> Aplikasi sangat mudah di akses dimana saja, kapan saja dan melalui perangkat apa saja 
                    </div>
                  </div>
                </div>
                <div class="col-md-6 offset-md-1">
                  <div class="f-right">
                    <img class="img-fluid" src="https://eposyandu.id/assets/images/ePuskesmas3D.svg" alt="Feature">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </p>
        </div>

        <!---About Section----->
          <div class="container">
            <div class="row text-center">
              <div class="col-md-8 offset-md-2">
                <div class="about-intro">
                  <h1 style="padding-top: 30px;">4 Langkah Pencatatan <span class="highlight">ePosyandu</span></h1>
                  <!-- <h1>Pencatatan dan pelaporan yang cepat, akurat dan akuntabel</h1> -->
                </div>
                <div class="">
                      <img class="img-fluid" src="https://eposyandu.id/assets/images/ui.png" alt="About">
                </div>
              </div>
              <div class="col-md-3">
                <div class="about-txt-inner">
                  <div class="num" style="background-color:#75cfd6">
                    1
                  </div>
                  <div class="about-txt">
                    <p>Pendataan Profile Balita
</p>
                  </div>
                </div>
              </div>
              <div class="col-md-3">
                <div class="about-txt-inner">
                  <div class="num" style="background-color:#FF9999">
                    2
                  </div>
                  <div class="about-txt">
                    <p>Pendaftaran
</p>
                  </div>
                </div>
              </div>
              <div class="col-md-3">
                <div class="about-txt-inner">
                  <div class="num" style="background-color:#4f77ff">
                    3
                  </div>
                  <div class="about-txt">
                    <p>Pencatatan hasil penimbangan/ Imunisasi</p>
                  </div>
                </div>
              </div>
               <div class="col-md-3">
                <div class="about-txt-inner">
                  <div class="num" style="background-color:#4ceb53">
                    4
                  </div>
                  <div class="about-txt">
                    <p>Pelaporan</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>


        <div id="pricing" class="pricing-sm">
        
          <div class="container">
            <div class="row">
              <div class="col-lg-5">
                <div class="review-pitch">
                  <h2>Klien Kami  </h2>
                  <p style="text-align: justify;">Kami memilik lebih dari 1000 klien yang tersebar se Nusantara , berbagai macam instasi,  Puskesmas, Klinik, Posyandu, Pustu, Rummah Sakit. untuk mewujudkan pelayanan kesehatan yang Prima.Kini Saatnya Instansi anda untuk bergabung bersama kami!!</p>
                </div>
                <div class="counter-section">
                  <div class="row text-center">
                    <div class="col-sm-3 col-xs-6">
                      <div class="counter-up">
                        <div class="counter-icon">
                          <img src="https://eposyandu.id/assets/icons/puskesmas.png" width="60" alt="Press">
                        </div>
                        <h3><span class="counter">1024</span><!-- K+ --></h3>
                        <div class="counter-text">
                          <h4>Puskesmas Online</h4>
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-3 col-xs-6">
                      <div class="counter-up">
                        <div class="counter-icon">
                          <img src="https://eposyandu.id/assets/icons/pustu.png" width="60" alt="Projects">
                        </div>
                        <h3><span class="counter">895</span></h3>
                        <div class="counter-text">
                          <h4>Pustu Online</h4>
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-3 col-xs-6">
                      <div class="counter-up">
                        <div class="counter-icon">
                          <img src="https://eposyandu.id/assets/icons/posyandu.png" width="60" alt="Press">
                        </div>
                        <h3><span class="counter">950</span></h3>
                        <div class="counter-text">
                          <h4>Posyandu Online</h4>
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-3 col-xs-6">
                      <div class="counter-up">
                        <div class="counter-icon">
                          <img src="https://eposyandu.id/assets/icons/dinkes.png" width="60" alt="Press">
                        </div>
                        <h3><span class="counter">58</span></h3>
                        <div class="counter-text">
                          <h4>Dinas Kesehatan</h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-6 offset-lg-1">
                <div class="review-section">
                  <div id="reviews" class="review-section">
                    <div class="container">
                      <div class="row text-center">
                        <div class="col-sm-12">
                          <div class="reviews owl-carousel owl-theme">
                           
                            <div class="review-single">
                              <img class="rounded-circle" src="https://dikeslobar.files.wordpress.com/2017/02/img-20170223-wa00002.jpg" alt="Client Testimonoal" />
                              <div class="review-text">
                                <p>Semua Bayi dan Balita di Kabupaten Lombok Barat, dipastikan dimonitor kesehatannya dan pertumbuhannya dengan aplikasi ePosyandu. Jika terdapat anomaly, Dinas Kesehatan akan turun tangan secara langsung untuk memberikan solusi.</p>
                                <h3>Drs. H. Rachman Sahnan Putra, M.Kes </h3>
                                <h4>Kepala Dinas Kesehatan Kab. Lombok Barat</h4>
                                <i class="ion ion-star"></i>
                                <i class="ion ion-star"></i>
                                <i class="ion ion-star"></i>
                                <i class="ion ion-star"></i>
                                <i class="ion ion-ios-star-half"></i>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

        <div id="footer" class="footer">
          <div class="container">
            <div class="row">
              <div class="col-md-4">
                <h2>ePosyandu Penambangan</h2>
                <br>
                <p> Sistem informasi mengenai Posyandu yang berada di Desa Penambangan, Kecamatan Curahdami, Kabupaten Bondowoso</p>
                <ul class="footer-subx">
                </ul>
              </div>

               
               
              <div class="col-md-4  ">
                <h2>Follow Us</h2>
                <br>
                <ul class="social">
                  
                  <li ><a href="https://www.facebook.com/infokesindonesia/" target="_blank"><img class="zoom" src="https://eposyandu.id/assets/icons/facebook.png" width="35" alt="Social"></a></li>

                  <li><a href="https://twitter.com/infokes_id" target="_blank"><img class="zoom" src="https://eposyandu.id/assets/icons/twitter.png" width="35" alt="Social"></a></li>
                  
                  <li><a href="https://www.youtube.com/channel/UCI-o9By31PePNC4dvkhVaDA" target="_blank"><img class="zoom" src="https://eposyandu.id/assets/icons/youtube.png" width="35" alt="Social"></a></li>
                  
                  <li><a href="https://www.instagram.com/infokesindonesia/?hl=id" target="_blank"><img class="zoom" src="https://eposyandu.id/assets/icons/instagram.png" width="35" alt="Social"></a></li>
                </ul>
                <!-- <ul class="footer-nav">
                  <li><a href="#">About</a></li>
                  <li><a href="#">Support</a></li>
                  <li><a href="#">Contact</a></li>
                </ul> -->
                <a class="f-mail" href="https://wa.me/+6281914578902">Phone : +62 819-1457-8902 </a>
                <br>
                <a class="f-mail" href="mailto:niezsalman2@gmail.com">Mail : niezsalman2@gmail.com</a>
              </div>

               <div class="col-md-4">
                <h2>Contact Us</h2>
                <br>
                <iframe style="background-color:#2180E08E;padding:10px" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15807.05595843089!2d113.7897958!3d-7.9197032!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x70503ac72364b96a!2sBalai%20Desa%20Penambangan!5e0!3m2!1sen!2sid!4v1655386467417!5m2!1sen!2sid" width="110%" frameborder="0" allowfullscreen=""></iframe>
               <br>
                <p style="text-align: center;"></p>
              </div>


            </div>

           
        </div>
<div class="copyright text-center" style="background-color:#2180e0e6;"><h2>
<span class="highlight" style="color:white;font-size: 14px;height: 90px;line-height: 50px;text-align: center;border: 0px dashed #f69c55;">&copy; Copyright :  2022  Posyandu Penambangan
</strong></span></h2></div>
<div class="copyright text-center" style="background-color:#2180e0e6;"><h2>
<div class="credits">
<span class="highlight" style="color:white;font-size: 14px;height: 90px;line-height: 50px;text-align: center;border: 0px dashed #f69c55;">
Designed by <a href="https://eposyandu.id/" target="blank" style="color:#ffff00">Eposyandu.id   </a> &nbsp <a href="https://bootstrapmade.com/" target="blank" style="color:#ffff00">BootstrapMade  </a>
                </span>
</div>
                </div>


        <!-- Scroll To Top -->
          <a id="back-top" class="back-to-top js-scroll-trigger" href="#main">
            <i class="ion-android-navigate"></i>
          </a>
        <!-- Scroll To Top Ends-->
      </div> <!-- Main -->
    </div><!-- Wrapper -->


    <!-- Jquery and Js Plugins -->
    <script src="https://eposyandu.id/assets/js/jquery-2.1.1.js"></script>
    <script src="https://eposyandu.id/assets/js/popper.min.js"></script>
    <script src="https://eposyandu.id/assets/js/bootstrap.min.js"></script>
    <script src="https://eposyandu.id/assets/js/jquery.validate.min.js"></script>
    <script src="https://eposyandu.id/assets/js/plugins.js"></script>
    <script src="https://eposyandu.id/assets/js/jquery.accordion.js"></script>
    <script src="https://eposyandu.id/assets/js/validator.js"></script>
    <script src="https://eposyandu.id/assets/js/contact.js"></script>
    <script src="https://eposyandu.id/assets/js/custom.js"></script>
  </body>
</html>
