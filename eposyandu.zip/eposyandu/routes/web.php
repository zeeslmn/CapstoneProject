<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\OrangTuaController;
use App\Http\Controllers\BalitaController;
use App\Http\Controllers\LaporanController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class, 'index']);

Route::get('/login', [HomeController::class, 'login']);
Route::post('/postlogin', [HomeController::class, 'postlogin']);
Route::get('/logout', [HomeController::class, 'logout']);
Route::get('/admin', [HomeController::class, 'admin']);

Route::get('/orangtua', [OrangTuaController::class, 'index']);
Route::get('/orangtua/create', [OrangTuaController::class, 'create']);
Route::post('/orangtua/post', [OrangTuaController::class, 'post']);
Route::get('/orangtua/{id}/edit', [OrangTuaController::class, 'edit']);
Route::post('/orangtua/{id}/update', [OrangTuaController::class, 'update']);
Route::get('/orangtua/{id}/delete', [OrangTuaController::class, 'delete']);

Route::get('/balita', [BalitaController::Class, 'index']);
Route::get('/balita/create', [BalitaController::class, 'create']);
Route::post('/balita/post', [BalitaController::class, 'post']);
Route::get('/balita/{id}/edit', [BalitaController::class, 'edit']);
Route::post('/balita/{id}/update', [BalitaController::class, 'update']);
Route::get('/balita/{id}/delete', [BalitaController::class, 'delete']);

Route::get('/laporan', [LaporanController::Class, 'index']);
Route::get('/laporan/create', [LaporanController::class, 'create']);
Route::post('/laporan/post', [LaporanController::class, 'post']);
Route::get('/laporan/{id}/edit', [LaporanController::class, 'edit']);
Route::post('/laporan/{id}/update', [LaporanController::class, 'update']);
Route::get('/laporan/{id}/delete', [LaporanController::class, 'delete']);